function nueva_pagina(){
    alert("Llegando a nueva página")
}

function form_msg(){
    alert("Gracias por su comentario miss")
}